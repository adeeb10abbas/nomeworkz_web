<?php 
$conn = mysqli_connect("localhost","nomeworkz","6?UhnjY5)sK%","nome") or die("there are some problem");
?>