<?php

echo '<script language="javascript">';
echo 'alert("Thank You. Your Project Submitted Successfully,You will Get Notification After Groome Approval!");';
echo 'window.location.href="index.php";';
echo '</script>';

?>